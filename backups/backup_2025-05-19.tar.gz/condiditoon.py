day_of_week= input("batao: ").lower()
print(day_of_week)

if (day_of_week == "sunday" or day_of_week == "monday"):
  print("hell yeah")

else: 
  print("work days")
