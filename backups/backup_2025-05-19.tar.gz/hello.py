print('hello world')
name=input("name: ")
print(name)

clouds=["1","aws","gcp","azure"]

for i in clouds:
    print(" ")
    print(i)